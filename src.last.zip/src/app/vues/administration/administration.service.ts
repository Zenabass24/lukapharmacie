import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


interface IUser {
  id?: number,
  name: string,
  firstname: string,
  birthdate: string,
  fonction: string,
  email: string,
  username: string,
  activated?: boolean,
  password?: string,
  role: number,
}

// var list_materiel = [
//   {idMat: 1, natureMat: "Informatique", libelleMat: "Imprimante lazer", etatMat: 1, type:}
// ]



const headers = new HttpHeaders().set('content-type', 'application/json')

const API_URL = 'http://127.0.0.1:8000/api/v1/users'
// const API_URL = 'http://192.168.100.36.8000/api/v1'


@Injectable({
  providedIn: 'root'
})
export class AdministrationService {

  public abonnes!: IUser[]

  constructor( private readonly http: HttpClient ) {  }

  public getUsers(): Observable<any> {

    return this.http.get<any>(`${API_URL}/getall`);

  }
}
