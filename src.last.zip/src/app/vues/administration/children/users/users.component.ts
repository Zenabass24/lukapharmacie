import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AuthService } from 'src/app/auth/service/auth.service';
import { DialogAlertSuppressionComponent } from 'src/app/components/dialog-alert-suppression/dialog-alert-suppression.component';
import { DialogRegisterUserComponent } from 'src/app/components/dialog-register-user/dialog-register-user.component';
import { AdministrationService } from '../../administration.service';

interface IUser {
  id?: string,
  name: string,
  firstname: string,
  fonction: string,
  email: string,
  username: string,
  password: string,
  activated?: boolean,
  role: number
}

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

  private selectedUser = {id:0}

  search() {
    // Convertissez le texte de recherche en minuscules pour une recherche insensible à la casse
    const searchText = this.searchText.toLowerCase();

    // Utilisez la méthode filter pour filtrer les utilisateurs en fonction du texte de recherche
    this.usersFiltres = this.users.filter((data: any) => {
      const name = data.name.toLowerCase();
      const firstname = data.firstname.toLowerCase();
      return name.includes(searchText) || firstname.includes(searchText);
    });
    // this.loadUsersList()
  }

searchText: any;
deleteUser() {

  if (!this.selectedUser) {
    alert('Vous n\'avez selectionné aucune ligne !')
  } else {
    this.openDialogSuppression()
  }
}
openDialogRegisterDemande() {
throw new Error('Method not implemented.');
}

  private _filtreUser = '';

  public users: any = [];

  public usersFiltres: any[] = []

  public errorMsg!: string

  public showSpinner = true

  public showSpinner2 = false


  //Centre

  public selectAll = true



  public showFilter: boolean = true

  val : 'add' | 'expand_more' = 'expand_more'

  //Nouvel abonne

  createNewUser: boolean = false

  //Paiement

  critere:  'all' | 'inLine' =  'all';

  typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers'];

  constructor( private usersService: AdministrationService, private authService: AuthService, private matDialog: MatDialog ) { }

  ngOnInit(): void {

    this.loadUsersList()

  }

  // OK
  public loadUsersList () {
    this.usersService.getUsers().subscribe({

      next: users => {

        this.users = users

        this.usersFiltres = this.users

        console.log('LISTE DES UTILISATEURS ', this.users )

        this.showSpinner = false

      },

      error: err => this.errorMsg = err

    })
  }

  get filtreUser (): string {

    return this._filtreUser;

  }

  private filtreIdUsers(critere: string): any[] {

    critere = critere.toLocaleLowerCase()

    const resultat = this.users.filter(

      (data: any) => data.id.toLocaleLowerCase().indexOf(critere) !== -1

    )

    return resultat;

  }

  private filtreNomsUsers(critere: string): any[] {

    critere = critere.toLocaleLowerCase()

    const resultat = this.users.filter(

      (data: any) =>

        data.RefAbonne.toLocaleLowerCase().indexOf(critere) !== -1

    )

    console.log('RESULT OF FILTER', resultat)

    return resultat
  }


  researchUsersBy() {

    alert('Vous recherchez les utilisateurs selon les criteres suivants: ')

  }

  toggleFilter() {

    this.showFilter = !this.showFilter

    this.val = 'add'

    if( this.showFilter ) {

      this.val = 'expand_more'

    } else{
      this.val = 'add'
    }

  }

  nouvelUser (): void {

    this.createNewUser = true

  }

  cancelCreation (): void {
    this.createNewUser = false
  }

  enregNewUser (): void {

    this.showSpinner2 = true

    setTimeout(
      () => {
        this.showSpinner2 = false
        this.createNewUser = false
      },
      4000
    )

  }



  public onUserSelect(user: any) {
    console.log('Matériel sélectionné :', user);
    this.selectedUser = user
  }



  // -----------------------------

  public openDialogRegisterUser () {

    var dialogRef = this.matDialog.open(DialogRegisterUserComponent, {
      width: '600px',
    })


    // Getter l'evenement de la boite de dialogue
    dialogRef.componentInstance.dialogClosed.subscribe(result => {
      console.log('Résultat de la boîte de dialogue:', result);
      // Faites quelque chose avec le résultat de la boîte de dialogue
      this.loadUsersList() 
    });

  }


  // ----------------------------------

  openDialogSuppression(): void {
    const dialogRef = this.matDialog.open(DialogAlertSuppressionComponent, {
      width: '350px',
      data: { choices: ['Annnuler', 'Valider'] } // Données à passer à la boîte de dialogue
    });

    const self = this

    // Abonnement à la fermeture de la boîte de dialogue et récupération du résultat
    dialogRef.afterClosed().subscribe(result => {
      console.log('Choix de l\'utilisateur :', result);

      const id = self.selectedUser.id | 0



      if (result == 'Valider') {
        self.authService.deleteUser(id).subscribe({
          next: result => {
            console.log("Result...", result)
            self.loadUsersList()
          },
          error: err => {
            console.log("Result...", err)

          }
        })
      }
      // Utiliser le résultat selon vos besoins
    });
  }



}
