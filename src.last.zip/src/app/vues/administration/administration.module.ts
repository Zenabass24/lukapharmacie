import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './children/users/users.component';
import { RolesComponent } from './children/roles/roles.component';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import {MatButtonModule} from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogRegisterUserComponent } from 'src/app/components/dialog-register-user/dialog-register-user.component';
import { AdministrationRoutingModule } from './administration-routing.module';
import {MatAutocompleteModule} from '@angular/material/autocomplete';



@NgModule({
  declarations: [
    UsersComponent,
    RolesComponent,
    DialogRegisterUserComponent
  ],
  imports: [
    CommonModule,
    AdministrationRoutingModule,
    FormsModule,
    SharedModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatAutocompleteModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AdministrationModule { }
