import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AdministrationComponent } from "./administration.component";
import { RolesComponent } from "./children/roles/roles.component";
import { UsersComponent } from "./children/users/users.component";



const routes: Routes = [
    {path: '', redirectTo: 'users', pathMatch: 'full'},
    {
        path: '', component: AdministrationComponent,
        children: [
            {path: 'users', component: UsersComponent},
            {path: 'roles', component: RolesComponent}
        ]
    },
    // {path: 'users', component: UsersComponent},
    // {path: 'roles', component: RolesComponent}

]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class AdministrationRoutingModule {}
