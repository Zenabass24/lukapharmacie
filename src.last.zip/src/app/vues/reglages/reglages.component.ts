import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reglages',
  templateUrl: './reglages.component.html',
  styleUrls: ['./reglages.component.scss']
})
export class ReglagesComponent {

  constructor(private router: Router) { }

  isActive(link: string): boolean {
    return this.router.isActive(link, false);
  }

}
