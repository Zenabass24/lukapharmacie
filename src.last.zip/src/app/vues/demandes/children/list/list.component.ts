import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { DialogRegisterDemandeComponent } from 'src/app/components/dialog-register-demande/dialog-register-demande.component';
import { IDemande } from 'src/app/interfaces';
import { CommonService } from 'src/app/services/common.service';
import { DemandeService } from '../../service/demande.service';




@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent {
  public currentUserRole = ''
  public selectedDemande: any

  public dataDemande!: IDemande;

  public filtreMateriel = '';
  public demandes: IDemande[] = [];
  public demandesFiltres: IDemande[] = [];
  public showSpinner = true;
  public showSpinner2 = false;
  public errorMsg!: string;
  public searchText = ''

  constructor(
    private demandeService: DemandeService,
    private matDialog: MatDialog,
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private readonly commonService: CommonService
    ) {
        // Enregistrez les icônes nécessaires
        this.matIconRegistry.addSvgIcon(
          'checked',
          this.domSanitizer.bypassSecurityTrustResourceUrl('chemin/vers/icone_checked.svg')
        );
    }

  ngOnInit(): void {
    this.loadMaterielsList();
    this.currentUserRole = this.commonService.getCurrentUserRole()
  }


  public loadMaterielsList() {
    this.demandeService.getDemandes().subscribe({
      next: demandes => {
        this.demandes = demandes;
        this.demandesFiltres = this.demandes;
        console.log('Liste Des Demandes ', this.demandes);
        this.showSpinner = false;
      },
      error: err => this.errorMsg = err
    });
  }

  public openDialogRegisterDemande() {
    this.matDialog.open(DialogRegisterDemandeComponent, {
      width: '600px',
    });
  }

  public openDialogEditMateriel() {
    // Implémenter la logique de modification du matériel ici
    console.log()
  }

  public deleteMateriel() {
    // Implémenter la logique de suppression du matériel ici
  }


  // TODO
  search() {
    const searchText = this.searchText.toLowerCase();
    this.demandesFiltres = this.demandes.filter((data) => {
      // const idLigneEtatDeBesoin = data.idLigneEtatDeBesoin.toString().toLowerCase();
      const service = data.service.nom.toLowerCase();
      const natureMateriel = data.materiel.nature.toLowerCase();
      const type = data.materiel.type.toLowerCase();
      const description = data.etatDeBesoin.description.toLowerCase();
      const date = this.formatDate(data.etatDeBesoin.date).toLowerCase();
      const etat = data.etatDeBesoin.etat.toLowerCase();

      return (
        // idLigneEtatDeBesoin.includes(searchText) ||
        service.includes(searchText) ||
        natureMateriel.includes(searchText) ||
        type.includes(searchText) ||
        description.includes(searchText) ||
        date.includes(searchText) ||
        etat.includes(searchText)
      );
    });
  }


  // list.component.ts

  // ...

  // TODO

  public onMaterielSelect(demande: any) {
    console.log('Matériel sélectionné :', demande);
    this.selectedDemande = demande
  }


  // Méthode pour obtenir la couleur de fond en fonction de la valeur
  getColor(etat: string): string {
    switch (etat) {
      case 'ATTENTE':
        return 'yellow';
      case 'ATTENTE_VALIDATION':
        return 'gray';
      case 'ATTENTE_APPROBATION':
        return 'yellow';
      case 'VALIDEE':
        return 'green';
      case 'ANNULEE':
        return 'red';
      default:
        return '';
    }
  }


  // Méthode pour obtenir la classe d'icône en fonction de la valeur
  getIcon(etat: string): string {
    switch (etat) {
      case 'ATTENTE':
        return 'hourglass_empty'; // Remplacer par la classe CSS de l'icône jaune
      case 'ATTENTE_VALIDATION':
        return 'check'; // Remplacer par la classe CSS de l'icône grise
      case 'ATTENTE_APPROBATION':
        return 'check'; // Remplacer par la classe CSS de l'icône jaune
      case 'VALIDEE':
        return 'check_circle_outline'; // Remplacer par la classe CSS de l'icône verte
      case 'ANNULEE':
        return 'remove_done'; // Remplacer par la classe CSS de l'icône rouge
      default:
        return ''; // Remplacer par la classe CSS par défaut ou une chaîne vide si nécessaire
    }
  }





    // MANAGER
    public approuverDemande() {

      if (!this.selectedDemande) {
        alert('Vous n\'avez selectionné aucune ligne !')
      } else {

        if (this.selectedDemande.etatDeBesoin.etat == "VALIDEE") {
          alert('Cette commande est déjà validée !')
        } else {

      console.log('Selected Materiel...', this.selectedDemande.etatDeBesoin.etat)
      let etat = ''
      if (this.selectedDemande.etatDeBesoin.etat == "ATTENTE") {
        etat = "ATTENTE_VALIDATION"
      } else if (this.selectedDemande.etatDeBesoin.etat == "ATTENTE_APPROBATION") {
        etat = "VALIDEE"
      }

      if (this.selectedDemande.etatDeBesoin.etat == "ATTENTE_VALIDATION") {
        alert('Vous avez déjà approuvé cette demande !')
      } else {
        const data = {idEtatBesoin: this.selectedDemande.etatDeBesoin.id, statutEtatBesoin: etat}

        console.log('DATA...', data)

        if (!this.selectedDemande) {
          alert('Vous n\'avez selectionné aucune ligne !')
        } else {
          this.commonService.updateDemande(data, this.selectedDemande.etatDeBesoin.id).subscribe ({
            next: result => {
              console.log('Result...', result)
              alert('Mise à jours affectuée avec succès')
              this.loadMaterielsList()
              this.selectedDemande = null
            },
            error: err => {
              console.log('Result...', err)
            }
          })
        }
      }






    }
  }

    }

    // RSAF
    public validerDemande() {

      if (!this.selectedDemande) {
        alert('Vous n\'avez selectionné aucune ligne !')
      } else {

        if (this.selectedDemande.etatDeBesoin.etat == "VALIDEE") {
          alert('Cette commande est déjà validée !')
        } else {


        console.log('Selected Materiel...', this.selectedDemande.etatDeBesoin.etat)
        let etat = ''
        if (this.selectedDemande.etatDeBesoin.etat == "ATTENTE") {
          etat = "ATTENTE_APPROBATION"
        } else if (this.selectedDemande.etatDeBesoin.etat == "ATTENTE_VALIDATION") {
          etat = "VALIDEE"
        }

        if (this.selectedDemande.etatDeBesoin.etat == "ATTENTE_APPROBATION") {
          alert('Vous avez déjà approuvé cette demande !')
        } else {
          const data = {idEtatBesoin: this.selectedDemande.etatDeBesoin.id, statutEtatBesoin: etat}

          console.log('DATA...', data)


          this.commonService.updateDemande(data, this.selectedDemande.etatDeBesoin.id).subscribe ({
            next: result => {
              console.log('Result...', result)
              alert('Mise à jours affectuée avec succès')
              this.loadMaterielsList()
              this.selectedDemande = null
            },
            error: err => {
              console.log('Result...', err)
            }
          })
        }


      }
      }

    }

    // JUSTE LES DEUX
    public annulerDemande () {
      console.log('Selected Materiel...', this.selectedDemande.etatDeBesoin.etat)
      let etat =  "ANNULEE"


      const data = {idEtatBesoin: this.selectedDemande.etatDeBesoin.id, statutEtatBesoin: etat}

      console.log('DATA...', data)

      if (!this.selectedDemande) {
        alert('Vous n\'avez selectionné aucune ligne !')
      }


      this.commonService.updateDemande(data, this.selectedDemande.etatDeBesoin.id).subscribe ({
        next: result => {
          console.log('Result...', result)
        },
        error: err => {
          console.log('Result...', err)
        }
      })
    }



    public formatDate(date: any): string {


      let annee: any= null;
      let mois: any = null;
      let jours: any = null;

      const aujourdhui: Date = new Date();
      const annee_auj: number = aujourdhui.getFullYear();
      const mois_auj: number = aujourdhui.getMonth() + 1;
      const jours_auj: number = aujourdhui.getDate();

      if (typeof date === 'string' && date.length === 10) {

          const date_splited: string[] = date.split('-');
          annee = parseInt(date_splited[0]);
          mois = parseInt(date_splited[1]);
          jours = parseInt(date_splited[2]);
      } else {

          annee = date.getFullYear();
          mois = date.getMonth() + 1;
          jours = date.getDate();
      }

      let resultat: string = '';

      if (annee === annee_auj && mois === mois_auj && jours === jours_auj) {
          resultat = 'Aujourd\'hui';
      } else {

          switch (mois) {
              case 1:
                  mois = 'Janvier';
                  break;
              case 2:
                  mois = 'Février';
                  break;
              case 3:
                  mois = 'Mars';
                  break;
              case 4:
                  mois = 'Avril';
                  break;
              case 5:
                  mois = 'Mai';
                  break;
              case 6:
                  mois = 'Juin';
                  break;
              case 7:
                  mois = 'Juillet';
                  break;
              case 8:
                  mois = 'Août';
                  break;
              case 9:
                  mois = 'Septembre';
                  break;
              case 10:
                  mois = 'Octobre';
                  break;
              case 11:
                  mois = 'Novembre';
                  break;
              case 12:
                  mois = 'Décembre';
                  break;
          }

          resultat = jours + ' ' + mois + ' ' + annee;
      }

      return resultat;
    }



}
