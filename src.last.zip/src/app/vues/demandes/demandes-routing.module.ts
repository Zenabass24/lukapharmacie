import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ListComponent } from "./children/list/list.component";
import { DemandesComponent } from "./demandes.component";



const routes: Routes = [
    {path: '', redirectTo: 'list', pathMatch: 'full'},
    {
        path: '', component: DemandesComponent,
        children: [
            {path: 'list', component: ListComponent},
            // {path: 'roles', component: }
        ]
    },
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class DemandeRoutingModule {}
