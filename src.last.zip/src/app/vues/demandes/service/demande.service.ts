import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const headers = new HttpHeaders().set('content-type', 'application/json')
const API_URL = 'http://127.0.0.1:8000/api/v1/demandes'

@Injectable({
  providedIn: 'root'
})
export class DemandeService {

  constructor( private readonly http: HttpClient ) { }

  public getDemandes(): Observable<any> {

    return this.http.get<any>(`${API_URL}/getall`);

  }

}
