import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './children/list/list.component';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { DemandesComponent } from './demandes.component';
import { DialogRegisterDemandeComponent } from 'src/app/components/dialog-register-demande/dialog-register-demande.component';
import { DemandeRoutingModule } from './demandes-routing.module';



@NgModule({
  declarations: [
    ListComponent,
    // DemandesComponent,
    DialogRegisterDemandeComponent
  ],
  imports: [
    CommonModule,
    DemandeRoutingModule,
    SharedModule,
    MatSelectModule,
    FormsModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatIconModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DemandesModule { }
