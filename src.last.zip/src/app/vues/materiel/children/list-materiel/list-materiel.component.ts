import { Component } from '@angular/core';

@Component({
  selector: 'app-list-materiel',
  templateUrl: './list-materiel.component.html',
  styleUrls: ['./list-materiel.component.scss']
})
export class ListMaterielComponent {

}
