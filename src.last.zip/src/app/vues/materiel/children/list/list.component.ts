import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogAlertSuppressionComponent } from 'src/app/components/dialog-alert-suppression/dialog-alert-suppression.component';
import { DialogDetailsMaterielComponent } from 'src/app/components/dialog-details-materiel/dialog-details-materiel.component';
import { DialogRegisterMaterielComponent } from 'src/app/components/dialog-register-materiel/dialog-register-materiel.component';
import { CommonService } from 'src/app/services/common.service';
import { MaterielService } from '../../service/materiel.service';

interface IMateriel {
  idMat?: number,
  natureMat: string,
  libelleMat: string,
  etatMat: boolean,
  type: any,
  modele: any,
  marque: string,
  rayon: string
}

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss', '../../materiel.component.scss']
})
export class ListComponent {

  public currentUserRole = ''
  private selectedMateriel: any

  public filtreMateriel = '';
  public materiels: IMateriel[] = [];
  public materielsFiltres: IMateriel[] = [];
  public showSpinner = true;
  public showSpinner2 = false;
  public errorMsg!: string;
  public searchText = ''

  constructor(
    private materielsService: MaterielService,
    private matDialog: MatDialog,
    private readonly commonService: CommonService
    ) { }

  ngOnInit(): void {
    this.loadMaterielsList();
    this.currentUserRole = this.commonService.getCurrentUserRole()

  }

  public search() {
    this.materielsFiltres = this.materiels.filter(materiel => {
      return materiel.natureMat.toLowerCase().includes(this.searchText.toLowerCase()) ||
             materiel.libelleMat.toLowerCase().includes(this.searchText.toLowerCase()) ||
             materiel.type.toLowerCase().includes(this.searchText.toLowerCase()) ||
             materiel.modele.toLowerCase().includes(this.searchText.toLowerCase()) ||
             materiel.marque.toLowerCase().includes(this.searchText.toLowerCase());
    });
  }


  public loadMaterielsList() {
    this.materielsService.getMateriels().subscribe({
      next: materiels => {
        this.materiels = materiels;
        this.materielsFiltres = this.materiels;
        console.log('Liste Des Materiels ', this.materiels);
        this.showSpinner = false;
      },
      error: err => this.errorMsg = err
    });
  }

  public openDialogRegisterMateriel() {
    this.matDialog.open(DialogRegisterMaterielComponent, {
      width: '600px',
    });
  }

  public openDialogEditMateriel() {
    // Implémenter la logique de modification du matériel ici
    console.log()
  }

  public deleteMateriel() {
    // Implémenter la logique de suppression du matériel ici
    if (!this.selectedMateriel) {
      alert("Vous n'avez sélectionné aucune ligne !")
    }
    this.openDialogSuppression()
  }


  // SUPPRESSION
  public openDialogSuppression(): void {
    const dialogRef = this.matDialog.open(DialogAlertSuppressionComponent, {
      width: '350px',
      data: { choices: ['Annnuler', 'Valider'] } // Données à passer à la boîte de dialogue
    });
    const self = this

    // Abonnement à la fermeture de la boîte de dialogue et récupération du résultat
    dialogRef.afterClosed().subscribe(result => {
      console.log('Choix de l\'utilisateur :', result);

      const id = self.selectedMateriel.idMat | 0



      if (result == 'Valider') {
        self.commonService.deleteMateriel(id).subscribe({
          next: result => {
            console.log("Result...", result)
            self.loadMaterielsList()
          },
          error: err => {
            console.log("Result...", err)

          }
        })
      }
      // Utiliser le résultat selon vos besoins
    });
  }

  // Details
  public openDialogDetailMateriel(): void {

    if (this.selectedMateriel) {
      alert("Vous n'avez sélectionné aucune ligne !")
    } else {
      const dialogRef = this.matDialog.open(DialogDetailsMaterielComponent, {
        width: '550px',
        data: { materiel: this.selectedMateriel } // Données à passer à la boîte de dialogue
      });
      const self = this
    }

  }






  // list.component.ts

  // ...

  public onMaterielSelect(materiel: IMateriel) {
    console.log('Matériel sélectionné :', materiel);
    this.selectedMateriel = materiel
    // Vous pouvez maintenant utiliser les détails du matériel sélectionné comme vous le souhaitez, par exemple, les afficher en console, les afficher dans un formulaire, etc.
  }








}
