import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './children/list/list.component';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterielRoutingModule } from './materiel-routing.module';
import { DialogRegisterMaterielComponent } from 'src/app/components/dialog-register-materiel/dialog-register-materiel.component';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    ListComponent,
    DialogRegisterMaterielComponent
  ],
  imports: [
    CommonModule,
    MaterielRoutingModule,
    SharedModule,
    FormsModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatIconModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MaterielModule { }
