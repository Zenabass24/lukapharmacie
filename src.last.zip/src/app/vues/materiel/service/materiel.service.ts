import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IMateriel } from 'src/app/interfaces';

const headers = new HttpHeaders().set('content-type', 'application/json')
const API_URL = 'http://127.0.0.1:8000/api/v1/materiels'

@Injectable({
  providedIn: 'root'
})
export class MaterielService {

  public materiels!: IMateriel[]

  constructor( private readonly http: HttpClient ) {  }

  public getMateriels(): Observable<any> {

    return this.http.get<any>(`${API_URL}/getall`);

  }

}
