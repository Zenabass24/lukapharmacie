import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ListComponent } from "./children/list/list.component";
import { MaterielComponent } from "./materiel.component";



const routes: Routes = [
    {path: '', redirectTo: 'list', pathMatch: 'full'},
    {
        path: '', component: MaterielComponent,
        children: [
            {path: 'list', component: ListComponent},
            // {path: 'roles', component: }
        ]
    },
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class MaterielRoutingModule {}
