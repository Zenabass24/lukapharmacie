import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ListComponent } from "./children/list/list.component";
import { LivraisonComponent } from "./children/livraison/livraison.component";
import { CommandeComponent } from "./commande.component";



const routes: Routes = [
    {path: '', redirectTo: 'list', pathMatch: 'full'},
    {
        path: '', component: CommandeComponent,
        children: [
            {path: 'list', component: ListComponent},
            {path: 'livraisons', component: LivraisonComponent}
        ]
    },
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class CommandeRoutingModule {}
