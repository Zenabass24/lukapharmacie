import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

const headers = new HttpHeaders().set('content-type', 'application/json')
const API_URL = 'http://127.0.0.1:8000/api/v1/commandes'
const baseUrl = "http://127.0.0.1:8000/api/v1/commandes"

@Injectable({
  providedIn: 'root'
})
export class CommandeService {


  constructor( private readonly http: HttpClient ) { }

  public getCommandes(): Observable<any> {

    return this.http.get<any>(`${API_URL}/getall`);

  }

  public registerCommande( dataDemande: any ): Observable<any> {
    return this.http.post<any>(`${baseUrl}/register/`, dataDemande, {headers:headers}).pipe(
      tap((res: any) => {
        console.log( 'res ', res )
      })
    )
  }


  public updateCommande( dataCommande: any, id: number ): Observable<any> {
    return this.http.put<any>(`${baseUrl}/update/` + id, dataCommande, {headers:headers}).pipe(
      tap((res: any) => {
        console.log( 'res ', res )
      })
    )
  }

  public getAllFournisseurs(): Observable<any> {

    return this.http.get<any>(`${API_URL}/fournisseurs/getall`);

  }

}
