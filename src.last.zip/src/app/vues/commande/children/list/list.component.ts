import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { DialogRegisterCommandeComponent } from 'src/app/components/dialog-register-commande/dialog-register-commande.component';
import { ICommande } from 'src/app/interfaces';
import { CommonService } from 'src/app/services/common.service';
import { CommandeService } from '../../service/commande.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent {
  public currentUserRole = ''
  public selectedCommande: any

  public dataCommande!: ICommande;

  public filtreMateriel = '';
  public commandes: ICommande[] = [];
  public commandesFiltres: ICommande[] = [];
  public showSpinner = true;
  public showSpinner2 = false;
  public errorMsg!: string;
  public searchText = ''

  constructor(
    private commandeService: CommandeService,
    private matDialog: MatDialog,
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private readonly commonService: CommonService
    ) {
        // Enregistrez les icônes nécessaires
        this.matIconRegistry.addSvgIcon(
          'checked',
          this.domSanitizer.bypassSecurityTrustResourceUrl('chemin/vers/icone_checked.svg')
        );
    }

  ngOnInit(): void {
    this.loadCommandesList();
    this.currentUserRole = this.commonService.getCurrentUserRole()
  }


  public loadCommandesList() {
    this.commandeService.getCommandes().subscribe({
      next: commandes => {
        this.commandes = commandes;
        this.commandesFiltres = this.commandes;
        console.log('Liste Des Commandes ', this.commandes);
        this.showSpinner = false;
      },
      error: err => this.errorMsg = err
    });
  }

  public openDialogRegisterCommande() {
    var dialogRef = this.matDialog.open(DialogRegisterCommandeComponent, {
      width: '600px',
    });

        // Getter l'evenement de la boite de dialogue
        dialogRef.componentInstance.dialogClosed.subscribe(result => {
          console.log('Résultat de la boîte de dialogue:', result);
          // Faites quelque chose avec le résultat de la boîte de dialogue
          this.loadCommandesList()
        });
  }

  public openDialogEditMateriel() {
    // Implémenter la logique de modification du matériel ici
    console.log()
  }

  public deleteMateriel() {
    // Implémenter la logique de suppression du matériel ici
  }


  // TODO
  // search() {
  //   const searchText = this.searchText.toLowerCase();
  //   this.commandesFiltres = this.commandes.filter((data) => {
  //     // const idLigneEtatDeBesoin = data.idLigneEtatDeBesoin.toString().toLowerCase();
  //     const service = data.service.nom.toLowerCase();
  //     const natureMateriel = data.materiel.nature.toLowerCase();
  //     const type = data.materiel.type.toLowerCase();
  //     const description = data.commande.description.toLowerCase();
  //     const date = this.formatDate(data.commande.date).toLowerCase();
  //     const etat = data.commande.statut.toLowerCase();

  //     return (
  //       // idLigneEtatDeBesoin.includes(searchText) ||
  //       service.includes(searchText) ||
  //       natureMateriel.includes(searchText) ||
  //       type.includes(searchText) ||
  //       description.includes(searchText) ||
  //       date.includes(searchText) ||
  //       etat.includes(searchText)
  //     );
  //   });
  // }
search() {}

  // list.component.ts

  // ...

  // TODO

  public onMaterielSelect(commande: any) {
    console.log('Commande sélectionnée :', commande);
    this.selectedCommande = commande
  }


  // Méthode pour obtenir la couleur de fond en fonction de la valeur
  getColor(etat: string): string {
    switch (etat) {
      case 'ATTENTE':
        return 'yellow';
      case 'ATTENTE_VALIDATION':
        return 'gray';
      case 'ATTENTE_APPROBATION':
        return 'yellow';
      case 'VALIDEE':
        return 'green';
      case 'ANNULEE':
        return 'red';
      default:
        return '';
    }
  }


  // Méthode pour obtenir la classe d'icône en fonction de la valeur
  getIcon(etat: string): string {
    switch (etat) {
      case 'ATTENTE':
        return 'hourglass_empty'; // Remplacer par la classe CSS de l'icône jaune
      case 'ATTENTE_VALIDATION':
        return 'check'; // Remplacer par la classe CSS de l'icône grise
      case 'ATTENTE_APPROBATION':
        return 'check'; // Remplacer par la classe CSS de l'icône jaune
      case 'VALIDEE':
        return 'check_circle_outline'; // Remplacer par la classe CSS de l'icône verte
      case 'ANNULEE':
        return 'remove_done'; // Remplacer par la classe CSS de l'icône rouge
      default:
        return ''; // Remplacer par la classe CSS par défaut ou une chaîne vide si nécessaire
    }
  }





    // MANAGER
    public approuverCommande() {

      if (!this.selectedCommande) {
        alert('Vous n\'avez selectionné aucune ligne !')
      } else {

        if (this.selectedCommande.commande.statut == "VALIDEE") {
          alert('Cette commande est déjà validée !')
        } else {

      console.log('Selected Materiel...', this.selectedCommande.commande.statut)
      let etat = ''
      if (this.selectedCommande.commande.statut == "ATTENTE") {
        etat = "ATTENTE_VALIDATION"
      } else if (this.selectedCommande.commande.statut == "ATTENTE_APPROBATION") {
        etat = "VALIDEE"
      }

      if (this.selectedCommande.commande.statut == "ATTENTE_VALIDATION") {
        alert('Vous avez déjà approuvé cette commande !')
      } else {
        const data = {idCom: this.selectedCommande.commande.id, statutCom: etat}

        console.log('DATA...', data)

        if (!this.selectedCommande) {
          alert('Vous n\'avez selectionné aucune ligne !')
        } else {
          this.commandeService.updateCommande(data, this.selectedCommande.commande.id).subscribe ({
            next: result => {
              console.log('Result...', result)
              alert('Mise à jours affectuée avec succès')
              this.loadCommandesList()
              this.selectedCommande = null
            },
            error: err => {
              console.log('Result...', err)
            }
          })
        }
      }






    }
  }

    }

    // RSAF
    public validerCommande() {

      if (!this.selectedCommande) {
        alert('Vous n\'avez selectionné aucune ligne !')
      } else {

        if (this.selectedCommande.commande.statut == "VALIDEE") {
          alert('Cette commande est déjà validée !')
        } else {


        console.log('Selected Materiel...', this.selectedCommande.commande.statut)
        let etat = ''
        if (this.selectedCommande.commande.statut == "ATTENTE") {
          etat = "ATTENTE_APPROBATION"
        } else if (this.selectedCommande.commande.statut == "ATTENTE_VALIDATION") {
          etat = "VALIDEE"
        }

        if (this.selectedCommande.commande.statut == "ATTENTE_APPROBATION") {
          alert('Vous avez déjà approuvé cette commande !')
        } else {
          const data = {idCom: this.selectedCommande.commande.id, statutCom: etat}

          console.log('DATA...', data)


          this.commandeService.updateCommande(data, this.selectedCommande.commande.id).subscribe ({
            next: result => {
              console.log('Result...', result)
              alert('Mise à jours affectuée avec succès')
              this.loadCommandesList()
              this.selectedCommande = null
            },
            error: err => {
              console.log('Result...', err)
            }
          })
        }


      }
      }

    }

    // JUSTE LES DEUX
    public annulerCommande () {
      console.log('Selected Materiel...', this.selectedCommande.commande.statut)
      let etat =  "ANNULEE"


      const data = {idEtatBesoin: this.selectedCommande.commande.id, statutEtatBesoin: etat}

      console.log('DATA...', data)

      if (!this.selectedCommande) {
        alert('Vous n\'avez selectionné aucune ligne !')
      }


      this.commandeService.updateCommande(data, this.selectedCommande.commande.id).subscribe ({
        next: result => {
          console.log('Result...', result)
        },
        error: err => {
          console.log('Result...', err)
        }
      })
    }



    public formatDate(date: any): string {


      let annee: any= null;
      let mois: any = null;
      let jours: any = null;

      const aujourdhui: Date = new Date();
      const annee_auj: number = aujourdhui.getFullYear();
      const mois_auj: number = aujourdhui.getMonth() + 1;
      const jours_auj: number = aujourdhui.getDate();

      if (typeof date === 'string' && date.length === 10) {

          const date_splited: string[] = date.split('-');
          annee = parseInt(date_splited[0]);
          mois = parseInt(date_splited[1]);
          jours = parseInt(date_splited[2]);
      } else {

          annee = date.getFullYear();
          mois = date.getMonth() + 1;
          jours = date.getDate();
      }

      let resultat: string = '';

      if (annee === annee_auj && mois === mois_auj && jours === jours_auj) {
          resultat = 'Aujourd\'hui';
      } else {

          switch (mois) {
              case 1:
                  mois = 'Janvier';
                  break;
              case 2:
                  mois = 'Février';
                  break;
              case 3:
                  mois = 'Mars';
                  break;
              case 4:
                  mois = 'Avril';
                  break;
              case 5:
                  mois = 'Mai';
                  break;
              case 6:
                  mois = 'Juin';
                  break;
              case 7:
                  mois = 'Juillet';
                  break;
              case 8:
                  mois = 'Août';
                  break;
              case 9:
                  mois = 'Septembre';
                  break;
              case 10:
                  mois = 'Octobre';
                  break;
              case 11:
                  mois = 'Novembre';
                  break;
              case 12:
                  mois = 'Décembre';
                  break;
          }

          resultat = jours + ' ' + mois + ' ' + annee;
      }

      return resultat;
    }



}
