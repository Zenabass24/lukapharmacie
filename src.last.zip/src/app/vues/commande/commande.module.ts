import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './children/list/list.component';
import { LivraisonComponent } from './children/livraison/livraison.component';
import { DemandeRoutingModule } from '../demandes/demandes-routing.module';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    ListComponent,
    LivraisonComponent
  ],
  imports: [
    CommonModule,
    DemandeRoutingModule,
    SharedModule,
    MatSelectModule,
    FormsModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatIconModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CommandeModule { }
