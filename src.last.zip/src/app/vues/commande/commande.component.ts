import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-commande',
  templateUrl: './commande.component.html',
  styleUrls: ['./commande.component.scss']
})
export class CommandeComponent {

  constructor(private router: Router) { }

  isActive(link: string): boolean {
    return this.router.isActive(link, false);
  }
  
}
