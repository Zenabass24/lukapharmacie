import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterielComponent } from './vues/materiel/materiel.component';
import { HomeComponent } from './vues/home/home.component';
import { ToolbarComponent } from './components/toolbar/toolbar.component';
import { AdministrationComponent } from './vues/administration/administration.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './modules/shared/shared.module';
import { ListMaterielComponent } from './vues/materiel/children/list-materiel/list-materiel.component';
import { ParametresComponent } from './vues/parametres/parametres.component';
import { AuthModule } from './auth/auth.module';
import { AdministrationModule } from './vues/administration/administration.module';
import { DialogRegisterUserComponent } from './components/dialog-register-user/dialog-register-user.component';
import { DialogRegisterMaterielComponent } from './components/dialog-register-materiel/dialog-register-materiel.component';
import { MaterielModule } from './vues/materiel/materiel.module';
import { DemandesComponent } from './vues/demandes/demandes.component';
import { CommandeComponent } from './vues/commande/commande.component';
import { ReglagesComponent } from './vues/reglages/reglages.component';
import { DialogRegisterLivraisonComponent } from './components/dialog-register-livraison/dialog-register-livraison.component';
import { DialogRegisterDemandeComponent } from './components/dialog-register-demande/dialog-register-demande.component';
import { DemandesModule } from './vues/demandes/demandes.module';
import { DialogAlertSuppressionComponent } from './components/dialog-alert-suppression/dialog-alert-suppression.component';
import { DialogAlertNotificationComponent } from './components/dialog-alert-notification/dialog-alert-notification.component';
import { DialogDetailsMaterielComponent } from './components/dialog-details-materiel/dialog-details-materiel.component';
import { DialogRegisterCommandeComponent } from './components/dialog-register-commande/dialog-register-commande.component';
import { CommandeModule } from './vues/commande/commande.module';

@NgModule({
  declarations: [
    AppComponent,
    MaterielComponent,
    HomeComponent,
    ToolbarComponent,
    AdministrationComponent,
    ParametresComponent,
    ListMaterielComponent,
    DemandesComponent,
    CommandeComponent,
    ReglagesComponent,
    DialogRegisterLivraisonComponent,
    DialogAlertSuppressionComponent,
    DialogAlertNotificationComponent,
    DialogDetailsMaterielComponent,
    DialogRegisterCommandeComponent,
    // DialogRegisterDemandeComponent,
    // DialogRegisterUserComponent,
    // DialogRegisterMaterielComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    AuthModule,
    AdministrationModule,
    MaterielModule,
    DemandesModule,
    CommandeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
