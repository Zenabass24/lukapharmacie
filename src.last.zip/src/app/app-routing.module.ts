import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/guard/auth.guard';
import { AuthComponent } from './auth/views/auth/auth.component';
import { AdministrationRoutingModule } from './vues/administration/administration-routing.module';
import { CommandeRoutingModule } from './vues/commande/commande-routing.module';
import { DemandeRoutingModule } from './vues/demandes/demandes-routing.module';
import { HomeComponent } from './vues/home/home.component';
import { MaterielRoutingModule } from './vues/materiel/materiel-routing.module';
import { PageNotFoundComponent } from './vues/page-not-found/page-not-found.component';
import { ParametresComponent } from './vues/parametres/parametres.component';
import { ReglagesRoutingModule } from './vues/reglages/reglages-routing.module';

const routes: Routes = [
  {path: '', redirectTo: 'login', pathMatch: 'full'},
  {path: 'login', component: AuthComponent},
  {path: 'home', component: HomeComponent, canActivate: [AuthGuard]},
  {path: 'materiel', loadChildren: () => MaterielRoutingModule, canActivate: [AuthGuard]},
  {path: 'administration', loadChildren: () => AdministrationRoutingModule, canActivate: [AuthGuard]},
  {path: 'demande', loadChildren: () => DemandeRoutingModule, canActivate: [AuthGuard]},
  {path: 'commande', loadChildren: () => CommandeRoutingModule, canActivate: [AuthGuard]},
  {path: 'reglages', loadChildren: () => ReglagesRoutingModule, canActivate: [AuthGuard]},
  {path: 'parametres', component: ParametresComponent, canActivate: [AuthGuard]},
  {path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
