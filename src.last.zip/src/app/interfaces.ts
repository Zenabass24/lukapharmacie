export interface IMateriel {
  idMat?: number,
  natureMat: string,
  libelleMat: string,
  etatMat: boolean,
  type: any,
  modele: any | null,
  marque: string | null,
  rayon: string | null
}

// export interface IDemande {
//   idLigneEtatDeBesoin?: number,
//   quantiteEtatDeBesoin: number,
//   materiel: any,
//   etatDeBesoin: any
//   service: any
// }
export interface IDemande {
  idEtatBesoin?: number,
  dateEtatBesoin?: string,
  statutEtatBesoin?: string,
  descriptionEtatBesoin: string,
  quantiteMateriel?: number,
  materiel?: any

  idLigneEtatDeBesoin?: number,
  service?: any
  etatDeBesoin?: any
}

export interface ICommande {
  idCom?: number,
  dateCom: string,
  statutCom?: string,
  fournisseur?: string

  idLigneCom?: number,
  quantiteCom: number,
  materiel?: any,
  commande?: any
}



export interface IRole {
  id?:number,
  nom_role: string
}

export interface IUser {
  id?: string,
  name: string,
  firstname: string,
  birthdate: string,
  fonction: string,
  telephone: string,
  email: string,
  username: string,
  password: string,
  activated?: boolean,
  role: number,
  service?: number
}


export interface IService {
  idService?: number,
  nomService: string
}

// export interface IMateriel {
//   idMat?: number,
//   natureMat: string,
//   libelleMat: string,
//   etatMat: string,
//   type: string,
//   marque: string,
//   modele: string
// }




