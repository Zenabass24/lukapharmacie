import { Observable, timeout, tap } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';


interface userData {
  name?:string,
  email:string,
  password:string
}

const baseUrl = "http://127.0.0.1:8000/api/v1/users"

const headers= new HttpHeaders()

  .set('content-type', 'application/json')

@Injectable({
  providedIn: 'root'
})

export class AuthService {

  constructor(private http:HttpClient) { }

  loginUser(dataUser:any):Observable<any>{

    console.log('Login service...', dataUser)

    return this.http.post<any>(`${baseUrl}/signin`, dataUser, {headers:headers}).pipe(
      timeout(5000),
      tap (res => {
        console.log('RESULT...', res)
      })
    )

  }

  createUser(dataUser:any):Observable<any>{

    console.log('Creating user...', dataUser)

    return this.http.post<any>(`${baseUrl}/register/`, dataUser, {headers:headers}).pipe(
      tap(res => {
        console.log( 'res ', res )
      })
    )

  }

  editUser(dataUser: any): Observable<any>{

    return this.http.post('http://127.0.0.1:3000/users/update', dataUser, {headers: headers})

  }

  deleteUser(id: any): Observable<any> {

    return this.http.delete(`${baseUrl}/delete/` + id)

  }

}

