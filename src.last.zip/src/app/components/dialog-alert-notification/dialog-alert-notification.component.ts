import { Component } from '@angular/core';

@Component({
  selector: 'app-dialog-alert-notification',
  templateUrl: './dialog-alert-notification.component.html',
  styleUrls: ['./dialog-alert-notification.component.scss']
})
export class DialogAlertNotificationComponent {

}
